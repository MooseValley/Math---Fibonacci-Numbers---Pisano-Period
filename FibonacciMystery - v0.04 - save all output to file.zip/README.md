# Math - Fibonacci Mystery

* Author: Mike O'Malley
* Source File: FibonacciMysteryBigIntegers.java
* Description: Explore the Fibonacci Mystery and more.
* Inspiration: Fibonacci Mystery - Numberphile, https://www.youtube.com/watch?v=Nu-lW-Ifyec
* GitHub:      https://github.com/MooseValley/Math---Fibonacci-Mystery

